#!/usr/bin/env python3
"""Render a harmonized image as a fixed-grid, scene-aware pixel GIF."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps


BAYER4 = (0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)


def rgb(code: str) -> tuple[int, int, int]:
    code = code.lstrip("#")
    if len(code) != 6:
        raise ValueError(f"expected #RRGGBB, got {code!r}")
    return tuple(int(code[i:i + 2], 16) for i in (0, 2, 4))


def oklab(color: tuple[int, int, int]) -> tuple[float, float, float]:
    def linear(channel: int) -> float:
        s = channel / 255
        return s / 12.92 if s <= 0.04045 else ((s + 0.055) / 1.055) ** 2.4

    r, g, b = (linear(channel) for channel in color)
    l = (0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b) ** (1 / 3)
    m = (0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b) ** (1 / 3)
    s = (0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b) ** (1 / 3)
    return (
        0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
        1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
        0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s,
    )


def distance(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2


def in_region(x: int, y: int, cols: int, rows: int, region: list[float]) -> bool:
    return region[0] <= (x + 0.5) / cols <= region[2] and region[1] <= (y + 0.5) / rows <= region[3]


def quantize_scene(image: Image.Image, cfg: dict, palette: list[tuple[int, int, int]]) -> list[int]:
    cols, rows = cfg["cols"], cfg["rows"]
    sampled = ImageOps.fit(image.convert("RGB"), (cols, rows), method=Image.Resampling.LANCZOS)
    labs = [oklab(color) for color in palette]
    accent = cfg.get("accentIndex")
    accent_region = cfg.get("accentRegion", [0, 0, 1, 1])
    base, candidates = [], []
    for i, color in enumerate(sampled.get_flattened_data()):
        x, y = i % cols, i // cols
        source = oklab(color)
        options = [(distance(source, lab), idx) for idx, lab in enumerate(labs) if idx != accent]
        best_distance, best_index = min(options)
        base.append(best_index)
        if accent is not None and in_region(x, y, cols, rows, accent_region):
            gain = best_distance - distance(source, labs[accent])
            if gain > 0:
                candidates.append((gain, i))
    if accent is not None:
        budget = round(cols * rows * cfg.get("maxAccentFraction", 0.04))
        for _, i in sorted(candidates, reverse=True)[:budget]:
            base[i] = accent
    return base


def animated_indices(base: list[int], cfg: dict, frame: int, frames: int) -> list[int]:
    cols, rows = cfg["cols"], cfg["rows"]
    phase = 2 * math.pi * frame / frames
    current = base.copy()
    for motion in cfg.get("motions", []):
        region = motion.get("region", [0, 0, 1, 1])
        selected = set(motion["indices"])
        kind = motion["kind"]
        if kind == "shift":
            dx = round(motion.get("dx", 0) * math.sin(phase + motion.get("phase", 0)))
            dy = round(motion.get("dy", 0) * math.sin(phase + motion.get("phase", 0)))
            if dx == 0 and dy == 0:
                continue
            for y in range(rows):
                for x in range(cols):
                    if not in_region(x, y, cols, rows, region):
                        continue
                    sx, sy = max(0, min(cols - 1, x - dx)), max(0, min(rows - 1, y - dy))
                    if not in_region(sx, sy, cols, rows, region):
                        continue
                    dst, src = y * cols + x, sy * cols + sx
                    if base[dst] in selected or base[src] in selected:
                        current[dst] = base[src]
        elif kind == "pulse":
            replacement = motion["to"]
            for y in range(rows):
                for x in range(cols):
                    index = y * cols + x
                    if base[index] not in selected or not in_region(x, y, cols, rows, region):
                        continue
                    wave = math.sin(phase + x * motion.get("frequencyX", 0.24)
                                    + y * motion.get("frequencyY", 0.15))
                    if wave > motion.get("threshold", 0.45):
                        current[index] = replacement
        elif kind == "patches":
            replacement = motion["to"]
            for patch in motion["patches"]:
                cx, cy = patch["x"], patch["y"]
                rx, ry = patch["rx"], patch["ry"]
                if not (0 < rx <= 6 and 0 < ry <= 6):
                    raise ValueError("animated patches must stay within a 12-cell diameter")
                activity = (1 + math.sin(phase * patch.get("cycles", 1)
                                         + patch.get("phase", 0))) / 2
                reach = 0.28 + 0.72 * activity
                for y in range(max(0, cy - ry), min(rows, cy + ry + 1)):
                    for x in range(max(0, cx - rx), min(cols, cx + rx + 1)):
                        index = y * cols + x
                        if base[index] not in selected or not in_region(x, y, cols, rows, region):
                            continue
                        jitter = (((x * 37 + y * 19 + cx * 11 + cy * 7) % 17) - 8) / 100
                        radius = ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2
                        if radius < max(0, reach + jitter) ** 2:
                            current[index] = replacement
        elif kind == "blink":
            progress = frame / frames
            peak = motion.get("at", 0.72)
            span = motion.get("duration", 0.20) / 2
            gap = min(abs(progress - peak), 1 - abs(progress - peak))
            close = max(0.0, 1 - gap / span)
            if close <= 0:
                continue
            cx = (region[0] + region[2]) / 2
            cy = (region[1] + region[3]) / 2
            half_width = (region[2] - region[0]) / 2
            half_height = (region[3] - region[1]) / 2
            for y in range(rows):
                for x in range(cols):
                    nx, ny = (x + 0.5) / cols, (y + 0.5) / rows
                    horizontal = abs((nx - cx) / half_width)
                    if horizontal >= 1:
                        continue
                    aperture = half_height * math.sqrt(1 - horizontal * horizontal)
                    vertical = abs(ny - cy)
                    if aperture * (1 - close) < vertical <= aperture:
                        current[y * cols + x] = motion["to"]
        else:
            raise ValueError(f"unknown motion kind: {kind}")
    for sprite in cfg.get("sprites", []):
        if sprite.get("hideOnBlink"):
            hidden = False
            for blink in cfg.get("motions", []):
                if blink["kind"] != "blink":
                    continue
                progress = frame / frames
                peak = blink.get("at", 0.72)
                span = blink.get("duration", 0.20) / 2
                gap = min(abs(progress - peak), 1 - abs(progress - peak))
                if max(0.0, 1 - gap / span) > 0.35:
                    hidden = True
                    break
            if hidden:
                continue
        origin_x, origin_y = sprite["origin"]
        motion_x = round(sprite.get("dx", 0) * math.sin(phase))
        motion_y = round(sprite.get("dy", 0) * math.sin(phase))
        poses = sprite.get("poses")
        if poses:
            cycle = (frame / frames * sprite.get("cycles", 1) + sprite.get("phase", 0)) % 1
            pixels = poses[int(cycle * len(poses))]
        else:
            pixels = sprite["pixels"]
        if "clearIndices" in sprite:
            clear_indices = set(sprite["clearIndices"])
            width = max(len(line) for line in pixels)
            for sy in range(len(pixels)):
                for sx in range(width):
                    x, y = origin_x + sx, origin_y + sy
                    if 0 <= x < cols and 0 <= y < rows and current[y * cols + x] in clear_indices:
                        current[y * cols + x] = sprite["clearTo"]
        for sy, line in enumerate(pixels):
            for sx, value in enumerate(line):
                x, y = origin_x + sx + motion_x, origin_y + sy + motion_y
                if value is not None and 0 <= x < cols and 0 <= y < rows:
                    current[y * cols + x] = value
    return current


def render(indices: list[int], cfg: dict, palette: list[tuple[int, int, int]], frame: int, frames: int) -> Image.Image:
    cols, rows, cell = cfg["cols"], cfg["rows"], cfg["cell"]
    grid = rgb(cfg["gridColor"])
    image = Image.new("RGB", (cols * cell, rows * cell), grid)
    draw = ImageDraw.Draw(image)
    phase = 2 * math.pi * frame / frames
    sub = cell // 3
    for y in range(rows):
        for x in range(cols):
            color = palette[indices[y * cols + x]]
            px, py = x * cell, y * cell
            draw.rectangle((px, py, px + cell - 2, py + cell - 2), fill=color)
            # 3×3 inner lattice, with quiet same-hue 2 px marks. The cell
            # remains one readable color even when texture animates.
            brightness = sum(color) / 765
            tone = tuple(round(channel * (0.91 if brightness > 0.77 else 0.88)
                               + (0 if brightness > 0.77 else 255 * 0.12)) for channel in color)
            for sy in range(3):
                for sx in range(3):
                    bayer = (BAYER4[((y * 3 + sy) & 3) * 4 + ((x * 3 + sx) & 3)] + 0.5) / 16
                    shimmer = 0.055 * math.sin(phase + x * 0.21 + y * 0.17) if (x * 17 + y * 11) % 5 == 0 else 0
                    if bayer < 0.31 + shimmer:
                        tx, ty = px + sx * sub + sub // 2, py + sy * sub + sub // 2
                        draw.rectangle((tx, ty, tx + 1, ty + 1), fill=tone)
            draw.line((px + cell - 1, py, px + cell - 1, py + cell - 1), fill=grid)
            draw.line((px, py + cell - 1, px + cell - 1, py + cell - 1), fill=grid)
    return image


def gif_palette(palette: list[tuple[int, int, int]], cfg: dict) -> Image.Image:
    colors = [rgb(cfg["gridColor"]), *palette]
    for color in palette:
        brightness = sum(color) / 765
        colors.append(tuple(round(channel * (0.91 if brightness > 0.77 else 0.88)
                                  + (0 if brightness > 0.77 else 255 * 0.12)) for channel in color))
    colors = list(dict.fromkeys(colors))
    indexed = Image.new("P", (1, 1))
    entries = [c for color in colors for c in color]
    indexed.putpalette(entries + [0] * (768 - len(entries)))
    return indexed


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path, help="harmonized still image")
    parser.add_argument("config", type=Path, help="scene palette and motion JSON")
    parser.add_argument("output", type=Path, help="output GIF path")
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text())
    if not (24 <= cfg["cols"] <= 96 and 24 <= cfg["rows"] <= 160 and cfg["cell"] >= 9 and cfg["cell"] % 3 == 0):
        parser.error("use 24–96 columns, 24–160 rows and a cell size divisible by 3")
    fps, seconds = cfg.get("fps", 12), cfg.get("seconds", 2.4)
    if not (4 <= fps <= 20 and 0.5 <= seconds <= 6):
        parser.error("fps or seconds outside supported range")
    palette = [rgb(color) for color in cfg["palette"]]
    if not (2 <= len(palette) <= 16):
        parser.error("palette must contain 2–16 colors")
    with Image.open(args.image) as source:
        base = quantize_scene(ImageOps.exif_transpose(source), cfg, palette)
    frames = max(2, round(fps * seconds))
    images = []
    pal = gif_palette(palette, cfg)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    for frame in range(frames):
        indices = animated_indices(base, cfg, frame, frames)
        bitmap = render(indices, cfg, palette, frame, frames)
        if frame == 0:
            bitmap.save(args.output.with_suffix(".png"))
        images.append(bitmap.quantize(palette=pal, dither=Image.Dither.NONE))
    images[0].save(args.output, save_all=True, append_images=images[1:],
                   duration=round(1000 / fps), loop=0, optimize=True, disposal=2)
    print(args.output)
    print(args.output.with_suffix(".png"))


if __name__ == "__main__":
    main()
